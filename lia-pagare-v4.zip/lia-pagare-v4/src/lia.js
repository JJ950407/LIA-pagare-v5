require('dotenv').config();

// Simple entrypoint to boot the WhatsApp bot
require('./bot');

