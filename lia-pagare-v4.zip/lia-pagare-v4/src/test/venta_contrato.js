{
  "chatId": "5215541790192@c.us",
  "steps": [
    { "text": "Hola", "delay": 100 },
    { "text": "Menu", "delay": 150 },
    { "text": "Generar contrato", "delay": 200 },

    { "text": "total: $250,000.00", "delay": 100 },
    { "text": "enganche: $50,000.00", "delay": 100 },
    { "text": "mensualidad: $6,500.00", "delay": 100 },
    { "text": "anualidadMonto: $10,000.00", "delay": 100 },
    { "text": "anualidadCount: 2", "delay": 50 },
    { "text": "anualidadMes: 12", "delay": 50 },

    { "text": "cliente: John Wick", "delay": 120 },
    { "text": "lote: A-12", "delay": 120 },
    { "text": "confirmar", "delay": 100 }
  ]
}
