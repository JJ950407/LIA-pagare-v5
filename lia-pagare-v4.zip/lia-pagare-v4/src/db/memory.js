const SESS = {};      
const DRAFTS = {};    
const LAST_MSG = {};  

module.exports = { SESS, DRAFTS, LAST_MSG };