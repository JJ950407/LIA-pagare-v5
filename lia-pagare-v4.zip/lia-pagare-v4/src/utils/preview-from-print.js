module.exports = async function writePreviewPng() {
  return null; // preview deshabilitado temporalmente para demo
};
